
% ************************************************************************
% *****  VCWDtool  ***** (v1. July 2023)
% ************************************************************************
% Written By: Rasoul Eskandari
%                     Marco Scaioni
%
%                     Corresponding E-mail: rasoul.eskandari@polimi.it
%                     "This work is licensed under a Creative Commons
%                     Attribution 4.0 International License [CC BY 4.0]"
%
%  Intilizing:
%          1.  Log in to (or Register first) https://www.visualcrossing.com/
%          2. In "Accoun Details", find and copy your API Key (< / > key)
%          3. Paste your key in "Inputs" section of this script,
%              instead of YOUR_KEY_HERE.
%           4. Prepare your "Date, Time, and Location" file follwoing the example csv file,
%               named "DateTimeLocationData.csv". Each row corresponds to a
%               single query.You can request for different times of a single day
%               in different rows. Please inter the Date and Time following
%               the format provided in the example file, and enter the
%               coordinates in Decimal Degree. 
%           5. Put the name of your csv file instead of
%               DateTimeLocationData in "Input section of this script (or
%               simply modify the exsiting DateTimeLocationData csv file). 
%
%           * Note: (July 2023) you can choose Free Plan of VisualCrossing, with
%           1000 query free per day. 
%
% Output:
%           1. A csv file, containing the weather data (the name starts with WDVC)
%           2. (Figure 1 & 2) Two plots, one for Daily and one for Current Time,
%               containing weather data.
%           3. (Figure 11) The location of Stations used for calculation of the
%               requested wather data at your selected location.
%
%           * Note: - For in-program applications, the expert users can extract the desired data
%                        from  cAllDataDL cell array, whose each cell corresponds to  
%                        each row of the request csv prepared by the user. 
%                       - The units are Metric (for more info, refer to "Data Extraction" section).

% ************************************************************************
% Inputs
% ************************************************************************
%VisualCrossing Key 
nKey="YOUR_KEY_HERE"; %EXAMPLE: nKey="XXX9XXXXXX9XXX9XXX9XXX9X9"

% Date and time and Location
tDTLdata=readtable('DateTimeLocationData.csv'); %Reading the request csv
nData=size(tDTLdata,1);

% ************************************************************************
% Data Request from VisualCrossing
% ************************************************************************
cAllDataDL=cell(nData,1);
for i=1:nData
    nLat=string(table2array(tDTLdata(i,3)));
    nLon=string(table2array(tDTLdata(i,4)));
    nDate=datestr(table2array(tDTLdata(i,1)),'yyyy-mm-dd');
    nTime=string(table2array(tDTLdata(i,2))); 
    seg1="https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/"+ nLat + "," + nLon + "/";
    seg2=nDate+"T"+nTime+"?key="+nKey+"&include=current&unitGroup=metric";    
    cAllDataDL{i}=webread(strcat(seg1,seg2));
end

% ************************************************************************
%  Data Extraction
% ************************************************************************
mExtData=[]; mExtDataCond=[];
for i=1:nData
    mExtDataTemp=[
                                  % Day-related information  (Day)
                                 cAllDataDL{i}.days.tempmax; %Minimum Day Temperature [°]
                                 cAllDataDL{i}.days.temp; %Mean Day Temperature [°]
                                 cAllDataDL{i}.days.tempmin; %Minimum Day Temperature [°]
                                 cAllDataDL{i}.days.pressure; %Mean Day Pressure [hPa]
                                 cAllDataDL{i}.days.humidity; %Mean Day Relative Humidity [%]
                                 cAllDataDL{i}.days.precip; %Mean Day Precipitation [mm]
                           
                                 %CurrentTime-related information (CuTi)
                                 cAllDataDL{i}.currentConditions.temp; %Current Time Temperature [°]
                                 cAllDataDL{i}.currentConditions.pressure; %Current Time Pressure [hPa]
                                 cAllDataDL{i}.currentConditions.humidity; %Current Time Relative Humiditym [%]
                                 cAllDataDL{i}.currentConditions.windspeed; %Current Time Wind Speed [km/h]
                                ];
    mExtData=[mExtData;mExtDataTemp'];
    mExtDataCond{i}= cAllDataDL{i}.currentConditions.conditions; %Current Time Weather Condition
end

% ************************************************************************
%  Export and Visualization
% ************************************************************************
% Saving csv
tFinalTable=[tDTLdata , array2table(mExtData) , array2table(mExtDataCond')];
 tFinalTable.Properties.VariableNames=["Date","Time","Latitude","Longitude","Day_TempMax","Day_TempMean",...
                                                                 "Day_TempMin","Day_Pressure","Day_Humidity","Day_Percipitation",...
                                                                 "CT_Temp","CT_Prressure","CT_Humidity","CT_WindSpeed","CT_WCondition"
                                                                    ];
writetable(tFinalTable,"VCWD_"+string(datestr(table2array(tDTLdata(1,1)),'yyyy-mm-dd'))+"_"+string(datestr(table2array(tDTLdata(end,1)),'yyyy-mm-dd'))+"_"+string(nData) + ".csv" )

% Data plots
figure(1)  %Day Information
sgtitle('Day-related information (Day)') 

subplot(4,1,1)  
plot(vDates,mExtData(:,1),'Color', 'r'  ,'LineWidth' , 2 , 'Marker', '.', 'MarkerSize',16,'MarkerEdgeColor','k')
hold on
plot(vDates,mExtData(:,2),'Color',[.7 .7 .7],'LineWidth' ,2 , 'Marker', '.', 'MarkerSize',16,'MarkerEdgeColor','k')
hold on
plot(vDates,mExtData(:,3),'Color', 'g' ,'LineWidth' , 2 , 'Marker', '.', 'MarkerSize',16,'MarkerEdgeColor','k')
legend('Max','Mean','Min')
ylabel('Temperature [°C]')

subplot(4,1,2)
plot(vDates,mExtData(:,4),'Color', 'm' ,'LineWidth' , 2 , 'Marker', '.', 'MarkerSize',16,'MarkerEdgeColor','k')
ylabel('Pressure [hPa]')

subplot(4,1,3)
plot(vDates,mExtData(:,5),'Color', 'y' ,'LineWidth' , 2 , 'Marker', '.', 'MarkerSize',16,'MarkerEdgeColor','k')
ylabel('Relative Humidity [%]')

subplot(4,1,4)
plot(vDates,mExtData(:,6),'Color', 'b' ,'LineWidth' , 2 , 'Marker', '.', 'MarkerSize',16,'MarkerEdgeColor','k')
ylabel('Precipitation [mm]')
xlabel('Time')


figure(2) %CurrentTime information
sgtitle('CurrentTime-related information (CT)') 

subplot(4,1,1)  
plot(vDates,mExtData(:,7),'Color', 'r'  ,'LineWidth' , 2 , 'Marker', '.', 'MarkerSize',16,'MarkerEdgeColor','k')
ylabel('Temperature [°C]')

subplot(4,1,2)
plot(vDates,mExtData(:,8),'Color', 'm' ,'LineWidth' , 2 , 'Marker', '.', 'MarkerSize',16,'MarkerEdgeColor','k')
ylabel('Pressure [hPa]')

subplot(4,1,3)
plot(vDates,mExtData(:,9),'Color', 'y' ,'LineWidth' , 2 , 'Marker', '.', 'MarkerSize',16,'MarkerEdgeColor','k')
ylabel('Relative Humidity [%]')

subplot(4,1,4)
plot(vDates,mExtData(:,10),'Color', 'g' ,'LineWidth' , 2 , 'Marker', '.', 'MarkerSize',16,'MarkerEdgeColor','k')
ylabel('Wind Speed [km/h]')
xlabel('Time')


% Stations plot
try % Stations and Selected Locations Plot
    cStations=struct2cell(cAllDataDL{1}.stations);
    nStations=size(cStations,1);
    vLAT=zeros(nStations,1); vLON=zeros(nStations,1);
    for i=1:nStations
        vLAT(i)=cStations{i}.latitude;
        vLON(i)=cStations{i}.longitude;
    end
    figure(11);
    set(gcf,'Visible','on')
    geoaxes('Basemap','satellite')
    hold on
    geoshow( vLON,vLAT, 'DisplayType', 'Point', 'Marker', '.', 'Color', 'red','MarkerSize',35);
    hold on
    geoshow( str2double(nLon),str2double(nLat), 'DisplayType', 'Point', 'Marker', '*', 'Color', 'k','MarkerSize',40);
    legend('Stations','Your Location')
    hold off
catch
    warning('There is a problem with plotting the Stations: Check if you have "Mapping Toolbox" or contorl the stations manually in "cAllDataDL" cell array ');
end

